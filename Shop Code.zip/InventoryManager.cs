using System.Colleections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using System.Threading.Tasks.Dataflow;

public class Inventorymanager : MonoBehaviour
{
    public InventorySlot[] itemSlots;
    public UseItem useItem;  
    public int gold;
    public TMP_Text goldText;
    public GameObject lootPrefab;
    public Transform player;

private void Start()
    {
        foreach (var slot in itemSlots)
        {
            slot.UpdateUI();
        }
    }
    private void OnEnable()
    {
        Loot.OnItemLooted += AddItem;
    }

    private void OnDisable()
    {
        Loot.OnItemLooted -= AddItem;
    }

    public void AddItem(ItemSO itemSO, int quantity)
    {
        if(itemSO.isGold)
        {
            gold += quantity;
            goldText.text = gold.ToString();
            return;
        }

        foreach (var slot in itemSlots)
        {
            if(slot.itemSO == itemSO && slot.quantity < itemSO.stackSize)
            {
                int availableSpace = itemSO.stackSize - slot.quantity;
                int amountToAdd = MathF.Min(availableSpace, quantity);

                slot.quantity += amountToAdd;
                quantity -= amountToAdd;

                slot.UpdateUI();

                if(quantity <= 0)
                    return; 
            }
        }

        foreach (var slot in itemSlots)
        {
            if(slot.itemSO == null)
            {
                    int amountToAdd = MathF.Min(itemSO.stackSize, quantity);
                    slot.itemSO =itemSO;
                    slot.quantity = quantity;
                    slot.UpdateUI();
                    return;
            }
        }

        if(quantity > 0)
            DropLoot(itemSO, quantity); 
    }

    public void DropItem(InventorySlot slot)
    {
        DropLoot(slot.itemSO, 1);
        slot.quantity--;
        if(slot.quantity <= 0)
        {
            slot.itemSO = null;
        }
        slot.UpdateUI();
    }


    private void DropLoot(ItemSO itemSO, int quantity)
    {
        Loot loot = Instantiate(lootPrefab, player.position, Quaternion.identity).GetComponent<Loot>();
        loot.Initialize(itemSO, quantity);
    }

    public void UseItem(InventorySlot slot)
    {
        if(slot.itemSO != null && slot.quantity >= 0)
        {
           useItem.ApplyItemEffects(slot.itemSO);
           slot.quantity--;
           if(slot.quantity <= 0)
           {
               slot.itemSO = null;
           }
           slot.UpdateUI();
        }
    }
}